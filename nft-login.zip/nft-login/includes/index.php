<?php
/**
 * Intentionally empty file.
 *
 * It exists to stop directory listings on poorly configured servers.
 *
 * @package     Nft_Login
 * @subpackage  Nft_Login/includes
 */
